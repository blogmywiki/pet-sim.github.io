These files are editable music modules created with 1tracker.

To open them up:

1. Download 1tracker at http://shiru.untergrund.net/software.shtml
2. Put peskytone.1te into /engines/
3. Now you can load *.1tm files with F3.

If you just want to look at notes, you can open these files
with a plain text editor, they're human readable.
