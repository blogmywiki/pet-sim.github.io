Faulty Robots - Commodore PET CB2 Music Album
СС-BY Shiru (shiru@mail.ru) 02'2021



About

Faulty Robots is a music album created for Commodore PET, a personal 
computer from 1977 that barely featured any sound capabilities at all. 
This is the result of work that has been done by me for The 8-bit Guy's 
PETSCII Robots game, but did not make it into the final product. I took 
a creative freedom from there, and turned my code and music sketches 
into a stand-alone chiptune album. You may consider it an unofficial 
fan-made soundtrack of sorts. 

The album features all-single channel music that creates illusion of few 
voices playing at once. This kind of music can actually play while a 
game is running on the machine. Songs take about 1000-1500 bytes of 
memory each. 

You can run the program on actual PET or an emulator, such as VICE or
MAME. Both has issues with sound emulation, the latter sounds all
wrong as of 0.228, so be aware. Hopefully this release will help to
fix these.

Compatibility between models is not guaranteed, it expected to work
on a 40xx or 80xx model with 16K of RAM and a disk drive (confirmed to
be working on a couple 50 Hz and 60 Hz 40xx units, at least).

Press 1...8 to play a song, any key to stop currently playing soug.
Press RUN/STOP to exit program. You can also use Q,E,X keys for exit.


Special thanks to David Murray, utz, mr287cc, and Joe Travis!



Changes history

26.02.21 - 80xx support added as a separate PRG file.
09.02.21 - Proper init for 'graph' mode, fixes shaking screen on 60 Hz,
           proper keys to exit program, performing hard reset on exit.
07.02.21 - Original release



David's original game: http://www.the8bitguy.com/product/petscii-robots/ 

Audio version: https://shiru8bit.bandcamp.com/album/faulty-robots

Support me at Patreon: https://www.patreon.com/shiru8bit